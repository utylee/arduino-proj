# ArduinoBTPS2
- Author: Evan Kale
- Email: evankale91@gmail.com
- Web: ISeeDeadPixel.com
- Blog: evankale.blogspot.ca
- YouTube: youtube.com/EvanKale91

See a demo video here:
https://youtu.be/UJaqHnPR-XE

- A non-interrupt based PS2 keyboard and mouse library for Arduino.
- Translates PS2 signals to Bluetooth signals.
- The main sketch is used for the Arduino Bluetooth Keyboard Mouse Adapter.
